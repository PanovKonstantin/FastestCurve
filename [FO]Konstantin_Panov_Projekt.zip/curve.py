import numpy as np
from conf import *

class FunctionCurve: 
    def __init__(self, equation, start=T_START, end=T_FINISH) -> None:
        self.equation = equation
        self.table = {}
        self.table['ts'] = np.linspace(start, end, T_NUM)
        self.gen_xy()
        self.gen_path()
        self.gen_slope()
        self.init_surface()
    
    def gen_xy(self):
        self.table['xy'] = [self.equation(t) for t in self.table['ts']]
        self.measure_szie()
    
    def gen_path(self):
        self.table['p'] = []
        self.table['p'].append(0)
        for i in range(1, len(self.table['xy'])):
            p1, p2 = self.table['xy'][i], self.table['xy'][i-1]
            diff_path = np.linalg.norm(p1 - p2)
            self.table['p'].append(self.table['p'][-1] + diff_path)
        
    def gen_slope(self):
        self.table['slope'] = []
        for i in range(0, len(self.table['xy']) - 1):
            xy1 = self.table['xy'][i]
            xy2 = self.table['xy'][i + 1]
            dx = (xy2[0] - xy1[0])
            dy = (xy2[1] - xy1[1])
            if dx == 0: dx = 0.00000001
            k =  dy / dx 
            theta = k / (sqrt(1 + k**2))
            if xy2[0] < xy1[0]: theta = -theta
            self.table['slope'].append(theta)
        self.table['slope'].append(self.table['slope'][-1])
    
    def measure_szie(self):
        xs = [xy[0] for xy in self.table['xy']]
        ys = [xy[1] for xy in self.table['xy']]
        max_x = max(xs)
        min_x = min(xs)
        max_y = max(ys)
        min_y = min(ys)
        self.x_scale = (GRAPH_WIDTH*0.9) / (max_x - min_x)
        self.y_scale = (GRAPH_HEIGHT*0.9) / (max_y - min_y)
        self.table['min_x'] = min_x * self.x_scale
        self.table['max_y'] = max_y * self.y_scale
        self.table['min_y'] = min(ys) * self.y_scale
        self.scale_to_screen()

    def scale_to_screen(self):
        scaled_xy = []
        for xy in self.table['xy']:
            scaled_xy.append(xy * np.array([self.x_scale, self.y_scale]))
        self.table['xy'] = np.array(scaled_xy)

    def init_surface(self):
        self.surface = pygame.Surface(GRAPH_SIZE, pygame.SRCALPHA, 32)
        self.surface = self.surface.convert_alpha()
        if (len(self.table['xy']) >= 2):
            minx = self.table['min_x']
            maxy = self.table['max_y']
            xys = self.table['xy']
            line = [coord_to_screen(xy, minx, maxy) for xy in xys]
            pygame.draw.aalines(self.surface, BLACK, False, line)
        self.rectangle = self.surface.get_rect().move(GRAPH_POSITION)
    
    def blit(self):
        screen.blit(self.surface, self.rectangle)
    
    def handle_drag(self, event, pause, resume):
        return False