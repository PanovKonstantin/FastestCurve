from conf import *
import pygame
class AccelerationArrow:
    def __init__(self) -> None:
        self.std = pygame.Surface((200, 200), pygame.SRCALPHA, 32)
        self.std = self.std.convert_alpha()
        color = RED
        pygame.draw.polygon(self.std, color, ((200, 200), (170, 190), (190, 170)))
        pygame.draw.line(self.std, color, (100, 100), (200, 200), 3)
    
    def blit(self, amp, angle, origin):
        x = y = int(abs(amp)/sqrt(2))*3
        arrow = pygame.transform.rotate(self.std, 45)
        arrow = pygame.transform.rotate(arrow, angle)
        if amp < 0: arrow = pygame.transform.rotate(arrow, 180)
        arrow = pygame.transform.scale(arrow, (x, y))
        half_width = int(arrow.get_width()/2)
        screen.blit(arrow, origin.move(-half_width, -half_width).move(POINT_R, POINT_R))
