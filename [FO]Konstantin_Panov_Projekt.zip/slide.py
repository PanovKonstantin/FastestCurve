import numpy as np
from point import *
from curve import *
from bezier import *
from conf import *

class Slide:
    def __init__(self, is_bezier=True, equation=None, points=[]) -> None:
        self.equation = equation
        self.points = np.array(points)*parameters['SCALE']/GRAPH_STEP
        self.is_bezier = is_bezier
        self.is_pause = False
        self.selected = False
        self.init_curve()
        self.init_point()
    
    def init_curve(self):
        if self.is_bezier:
            self.curve = Bezier(self.points)
        else:
            self.curve = FunctionCurve(self.equation)

    def init_point(self):
        self.point = Point(self.curve, self.curve.table)

    def move(self):
        self.point.move()

    def blit(self):
        self.curve.blit()
        self.point.blit()

    def handle_drag(self, event, pause, resume):
        return self.curve.handle_drag(event, pause, resume)

    def pause(self):
        if not self.is_pause:
            self.is_pause = True
            self.point.pause()
    
    def resume(self):
        if self.is_pause:
            self.is_pause = False
            self.point.resume()
    
    def reset(self):
        self.curve.redraw()
        self.point.reset()

    def set_selected(self):
        self.selected = True
        self.point.set_selected()
        self.curve.set_selected()

    def set_not_selected(self):
        self.selected = False
        self.point.set_not_selected()
        self.curve.set_not_selected()